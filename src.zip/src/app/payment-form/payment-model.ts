export class PaymentTransaction {
    cardName: string="";
    cardNo: string="";
    amount: number=0;
    status: string="";
  }